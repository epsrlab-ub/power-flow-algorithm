# -*- coding: utf-8 -*-
# @Time    : 7/22/2023 12:27 PM
# @Author  : Paulo Radatz
# @Email   : pradatz@epri.com
# @File    : fixed_device_size_1.py
# @Software: PyCharm

import py_dss_interface
import os
import pathlib
import numpy as np

from HCWebinar.hc_steps import HCSteps
from HCWebinar.feeder_condition import FeederCondition

script_path = os.path.dirname(os.path.abspath(__file__))
dss_file = pathlib.Path(script_path).joinpath("../../../feeders", "8bus", "Master.dss")
dss = py_dss_interface.DSS()

# Compile OpenDSS feeder model
dss.text(f"compile [{dss_file}]")

# Set Feeder Condition
FeederCondition.set_load_level_condition(dss, load_mult=0.2)

# Calculate HC
gen_fixed_size = 500
buses = ["4", "6", "7", "0", "3", "1", "2", "5"]

buses_used = list()
hosting_capacity_value = 0
for bus in buses:
    dss.circuit.set_active_bus(bus)
    kv = dss.bus.kv_base * np.sqrt(3)

    gen_bus = dss.bus.name
    gen_kv = kv
    gen_kw = gen_fixed_size

    # Add generator at bus
    HCSteps.add_fixed_size_gen(dss, gen_bus, gen_kv, gen_fixed_size)

    HCSteps.solve_powerflow(dss)

    if HCSteps.check_overvoltage_violation(dss):
        break
    else:
        hosting_capacity_value = hosting_capacity_value + gen_kw
        buses_used.append(bus)

# Print out results of simulation
print(HCSteps.result_distributed_info(buses_used,
                                      "Overvoltage",
                                      hosting_capacity_value,
                                      "offpeak",
                                      False,
                                      "Generator"))